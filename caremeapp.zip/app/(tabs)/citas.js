import React, { useContext, useState } from "react";
import { View, Text, FlatList, TouchableOpacity } from "react-native";
import { AuthContext } from "../../context/AuthContext";
import { ItemsHistory } from "../../components/screen/History/ItemsHistory";
import { CitasContext } from "../../context/CitasContext";

export default function CitasScreen() {

  const { user, membershipData, loading } = useContext(AuthContext);
  const {citas} = useContext(CitasContext);
  const { color1:dark, color2:light, color3:colorFondo } = membershipData.colors;
  const [selectedProcedimiento, setSelectedProcedimiento] = useState(null);
  const [selectedEstado, setSelectedEstado] = useState(null);


  const procedimientos = [...new Set(citas.map(cita => cita.procedimiento))];
  const estados = [...new Set(citas.map(cita => cita.estado))];

  const medicos = ["Dra. López", "Dr. Ramírez", "Dra. Sánchez", "Dr. Torres"];

  // 🔎 Filtro dinámico
  const filteredCitas = citas.filter((cita) => {
    return (
      (!selectedProcedimiento || cita.procedimiento === selectedProcedimiento) &&
      (!selectedEstado || cita.estado === selectedEstado)
    );
  });

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <View>
        {/* Filtros de procedimiento */}
        <Text style={{ fontSize: 16, fontWeight: "bold", marginBottom: 8 }}>
          Filtrar por procedimiento
        </Text>
        <FlatList
          horizontal
          data={procedimientos}
          keyExtractor={(item, index) => `${procedimientos}-${index}`}
          showsHorizontalScrollIndicator={false}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() =>
                setSelectedProcedimiento(
                  selectedProcedimiento === item ? null : item
                )
              }
              style={{
                padding: 8,
                marginRight: 8,
                borderRadius: 8,
                backgroundColor:
                  selectedProcedimiento === item ? "#3b82f6" : "#e5e7eb",
              }}
            >
              <Text
                style={{
                  color: selectedProcedimiento === item ? "#fff" : "#000",
                }}
              >
                {item}
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      <View>
        {/* Filtros de estado */}
        <Text style={{ fontSize: 16, fontWeight: "bold", marginVertical: 8 }}>
          Filtrar por estado
        </Text>
        <FlatList
          horizontal
          data={estados}
          keyExtractor={(item, index) => index.toString()}
          showsHorizontalScrollIndicator={false}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() =>
                setSelectedEstado(selectedEstado === item ? null : item)
              }
              style={{
                padding: 8,
                marginRight: 8,
                borderRadius: 8,
                backgroundColor:
                  selectedEstado === item ? "#10b981" : "#e5e7eb",
              }}
            >
              <Text
                style={{
                  color: selectedEstado === item ? "#fff" : "#000",
                }}
              >
                {item}
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      {/* Lista de citas */}
      <FlatList
        data={filteredCitas}
        keyExtractor={(item) => item.id}
        style={{ marginTop: 16 }}
        ItemSeparatorComponent={<View className="p-2"/>}
        renderItem={({ item }) => (
            <ItemsHistory 
              dark={dark} 
              procedimiento={item.procedimiento} 
              fecha={item.fecha}
              hora={item.hora}
              medico={item.especialista}
              estado={item.estado}
              buttons={'Activo'}
            />
        )}
      />
    </View>
  );
}
