import * as ImagePicker from "expo-image-picker";
import { useContext, useEffect, useState } from "react";
import { Button, View, Alert, ScrollView, Text, Pressable, FlatList } from "react-native";
import { AuthContext } from "../../context/AuthContext";
import ReportCard from "../../components/screen/Diagnostico/ReportCard";
import wpService from "../../services/wordpress";
import { useLoading } from "../../context/LoadingContext";
import { PostsContext } from "../../context/PostsContext";
import { Screen } from "../../components/Screen";
import { CameraIcon } from "../../components/Icons";
import { TextSubTitles, TextTitles } from "../../components/TextCustom";
import { ProductsContext } from "../../context/ProductsContext";
import ItemProduct from "../../components/screen/Diagnostico/ItemProduct";

export default function diagnostico() {
  const { user, token, membershipData } = useContext(AuthContext);
  const { lastReport, uploadReport } = useContext(PostsContext)
  const { runWithLoading } = useLoading();
  const {products} = useContext(ProductsContext)
  const [active, setActive] = useState('')

  const { color1:dark, color2:light, color3:colorFondo } = membershipData.colors;

  const handleTakePhoto = async () => {
    try {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== "granted") {
        Alert.alert("Permiso requerido", "Se necesita permiso para usar la cámara");
        return;
      }

      const result = await ImagePicker.launchCameraAsync({ allowsEditing: true, quality: 1 });
      if (!result.canceled) {
        await runWithLoading(
          async () => {
            const report = await uploadReport(result.assets[0]);
          },
          "Procesando imagen...", // 👈 se verá en el loader global
        );
      }
    } catch (err) {
      console.error("Error ❌", err);
    }
  };

  const toggleTakePhoto = () =>{
    if(active){
      setActive('')
    } else {
      setActive('active')
    }
  }
  return (
      <ScrollView
        className="flex-1" 
        showsVerticalScrollIndicator={false}

      > 
        <Screen withTopInset={false}>
            <View>
              {
                lastReport && !
                active?(
                  <View>
                    <Pressable onPress={toggleTakePhoto}>
                      {
                        ({pressed})=>(
                        <View className="justify-between flex-row py-3 items-center">
                          <TextTitles>Tu Análisis</TextTitles>
                          <TextSubTitles className="text-white p-3 rounded-3xl" style={{backgroundColor: dark}}>Realizar otro analisis</TextSubTitles>
                        </View>
                        )
                      }
                    </Pressable>
                    {
                      active&&(
                        <View className="bg-white justify-center items-center border-dashed border-2 border-gray-300 rounded-3xl p-6 gap-8 mb-5">
                          <View style={{backgroundColor: colorFondo}} className="p-10 rounded-full">
                            <CameraIcon size={30}/>
                          </View>
                          <TextTitles className="text-center">Toma una foto de tu rostro para comenzar el analisis</TextTitles>
                          <Pressable
                            onPress={handleTakePhoto}
                            className="w-full" 
                          >
                            {
                              ({pressed})=>(
                                <View className={`w-full py-4 justify-center items-center rounded-2xl ${pressed? 'opacity-50':'opacity-100'}`} style={{backgroundColor: dark}}>
                                  <TextTitles className="text-white">Tomar foto</TextTitles>
                                </View>
                              )
                            }
                
                          </Pressable>
                        </View>
                      )
                    }
                  </View>
                ):(
                  <View className="bg-white justify-center items-center border-dashed border-2 border-gray-300 rounded-3xl p-6 gap-8 mb-5">
                    <View style={{backgroundColor: colorFondo}} className="p-10 rounded-full">
                      <CameraIcon size={30}/>
                    </View>
                    <TextTitles className="text-center">Toma una foto de tu rostro para comenzar el analisis</TextTitles>
                    <Pressable
                      onPress={handleTakePhoto}
                      className="w-full" 
                    >
                      {
                        ({pressed})=>(
                          <View className={`w-full py-4 justify-center items-center rounded-2xl ${pressed? 'opacity-50':'opacity-100'}`} style={{backgroundColor: dark}}>
                            <TextTitles className="text-white">Tomar foto</TextTitles>
                          </View>
                        )
                      }
          
                    </Pressable>
                  </View>
                )
              }

              <View className="gap-5">
                <ReportCard report={lastReport} baseUrl={wpService.baseUrl} />
                <ItemProduct data={products} fondo={colorFondo} productReport={lastReport.procedimientos}/>
              </View>
            </View>
        </Screen>
      </ScrollView>
  );
}
