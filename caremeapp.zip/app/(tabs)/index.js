import { View, Text, ActivityIndicator, ScrollView, RefreshControl, Pressable, Image, ImageBackground } from 'react-native'
import { Screen } from '../../components/Screen'
import { ProfileElement } from '../../components/screen/home/ProfileElement'
import { Tarjeta } from '../../components/screen/home/Tarjeta'
import { AccesoDirecto } from '../../components/screen/home/AccesoDirecto'
import { HistorialCitas } from '../../components/screen/home/HistorialCitas'
import { Beneficios } from '../../components/screen/home/Beneficios'
import { Espace, Line } from '../../components/ElementsAux'
import { CalendarIcon, GiftIcon, NotificationIcon, TimeIcon } from '../../components/Icons'
import { AuthContext } from '../../context/AuthContext'
import { useContext, useEffect } from 'react'
import SectionContainer from '../../components/SectionContainer'
import { Link, Stack } from 'expo-router'
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { TextContent, TextIntro, TextSubTitles, TextTitles } from '../../components/TextCustom'
import { ItemsHistory } from '../../components/screen/History/ItemsHistory'
import Campaña from '../../assets/images/campaña.jpg'

export default function index() {
  const { user, membershipData, loading, token } = useContext(AuthContext);
  const fullName = `${user.first_name} ${user.last_name}`;
  const membresia = user.membresia;
  const { color1:dark, color2:light, color3:colorFondo } = membershipData.colors;
  const {benefits} = membershipData;
  
  const dataButtons = [
    {item: "Agendar", routPage: "agendar", icon:CalendarIcon, dark, light, colorFondo},
    {item: "Beneficios", routPage: "beneficios", icon:GiftIcon, dark, light, colorFondo},
    {item: "Historial", routPage: "citas", icon:TimeIcon, dark, light, colorFondo},
  ]
  return (
    <ScrollView
    className="flex-1 gap-5" 
    showsVerticalScrollIndicator={false}
    >
      <Screen className="gap-8 pt-8">
        <Stack.Screen
          options={{
            headerShown: false
          }}/>
          <View className='justify-between flex-row'>
            <View className='w-10/12'>
              <TextIntro className='text-3xl ' adjustsFontSizeToFit numberOfLines={1}>{user.first_name} {user.last_name} 👋</TextIntro>
            </View>
            <View>
              <NotificationIcon/>
            </View>
          </View>
          <Tarjeta nombre={user.first_name + " " + user.last_name} dark={dark} light={light} colorFondo={colorFondo} membresia={membresia} amountBenefits={user.amountBenefits} countBenefits={user.countBenefits}/>
          <View className="flex-row gap-5 justify-between">
            {
              dataButtons.map((item, index) => (
                  <AccesoDirecto
                    key={index}
                    item={item.item}
                    icon={item.icon}
                    routPage={item.routPage}
                    dark={item.dark}
                    light={item.light}
                    colorFondo={item.colorFondo}
                  />
              ))
            }
          </View>
          <View className="gap-3">
            <View className="justify-between flex-row items-center">
              <TextTitles className="text-black font-medium">Próximas Citas</TextTitles>
              <Link asChild href={`/(tabs)/citas`}>        
                <Pressable>
                  {({ pressed }) => (
                    <TextContent className={`text-xl font-normal ${pressed ? "opacity-50" : "opacity-100"} text-gray-500`}>Ver todas</TextContent>
                  )}
                </Pressable>
              </Link>
            </View>
            <View className='bg-white rounded-3xl'>
              <View className="gap-1">
                <ItemsHistory 
                  dark={dark} 
                  procedimiento={'Tensamax'} 
                  fecha={'2025-09-10'}
                  hora={'8:00 AM'}
                  medico={'Dra Lopez'}
                  estado={'Aprobada'}
                />
                <Line className="border-b-2 border-b-gray-100 h-1 w-full"/>
                <ItemsHistory 
                  dark={dark} 
                  procedimiento={'Tensamax'} 
                  fecha={'2025-09-10'}
                  hora={'8:00 AM'}
                  medico={'Dra Lopez'}
                  estado={'En espera'}
                />
              </View>
            </View>
          </View>
          <View className="gap-3">
            <View className="justify-between flex-row items-center">
              <TextTitles className="text-black font-medium">Tus Beneficios</TextTitles>
              <Link asChild href={`/(tabs)/beneficios`}>        
                <Pressable>
                  {({ pressed }) => (
                    <TextContent className={`text-xl font-normal ${pressed ? "opacity-50" : "opacity-100"} text-gray-500`}>Ver todas</TextContent>
                  )}
                </Pressable>
              </Link>
            </View>
            <Beneficios dark={dark} light={light} colorFondo={colorFondo} benefits={benefits} loading={loading}/>
          </View>

          <View className="gap-3">
            <View className="justify-between flex-row items-center">
              <TextTitles className="text-black font-medium">Promociones exclusivas</TextTitles>
              <Link asChild href={`https://careme360.com/descubre-nuestras-promociones`}>        
                <Pressable>
                  {({ pressed }) => (
                    <TextContent className={`text-xl font-normal ${pressed ? "opacity-50" : "opacity-100"} text-gray-500`}>Ver todas</TextContent>
                  )}
                </Pressable>
              </Link>
            </View>
            <View className='flex-1 rounded-3xl'>
              <ImageBackground className="w-full h-36 flex-1 justify-end items-start p-3" source={Campaña} resizeMode='cover' style={{borderRadius: 30}}>
                <TextTitles>Extreme Young</TextTitles>
                <Link asChild href={`https://wa.me/+573170366805?text=Hola%2C+quiero+saber+mas+informaci%C3%B3n+sobre+la+promoci%C3%B3n+de+EXTREME+YOUNG%2C+vengo+del+link+https%3A%2F%2Fcareme360.com%2Fpromocion%2Fextreme-young%2F`}>
                    <Pressable>
                      {({pressed})=>(
                        <TextContent className={`bg-white rounded-full p-3 ${pressed ? "opacity-50":"opacity-100"}`}>Solicitar ahora</TextContent>
                      )}
                    </Pressable>
                </Link>
              </ImageBackground>
            </View>
          </View>
    
      </Screen>
    </ScrollView>
  )
}
