import { View, Text, TextBase } from 'react-native'
import React, { useContext, useEffect } from 'react'
import { Stack, useLocalSearchParams } from 'expo-router'
import { Screen } from '../components/Screen'
import { AuthContext } from '../context/AuthContext';
import { TextContent, TextIntro, TextTitles } from '../components/TextCustom';

export default function Detail() {
    const { user, membershipData, loading } = useContext(AuthContext);
    const {beneficioID} = useLocalSearchParams()
    const benefit = membershipData.benefits.find(b => b.procedimiento === beneficioID);
    return (
    <Screen>
        <Stack.Screen
          options={{
            headerShown: true
          }}/>
        {benefit ? (
        <View>
            <TextTitles className="text-black">{benefit.procedimientoLabel}</TextTitles>
            <View>
              <TextContent>{benefit.descripcion}</TextContent>
            </View>
        </View>
        ) : (
        <Text>paila</Text>
        )}
    </Screen>
    );
}