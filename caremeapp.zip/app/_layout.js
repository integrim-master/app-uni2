import { Link, Slot, Stack, usePathname, useRouter } from 'expo-router';
import { useContext, useEffect, useState } from 'react';
import { AuthContext, AuthProvider } from '../context/AuthContext';
import "../global.css"
import { ActivityIndicator, Pressable, SafeAreaView, StatusBar, Text, View } from 'react-native';
import Toast from 'react-native-toast-message';
import { toastConfig } from '../constants/toastConfig';
import { useFonts, Poppins_400Regular, Poppins_600SemiBold, Poppins_700Bold } from '@expo-google-fonts/poppins';
import { ActionSheetProvider } from "../provider/ActionSheetProvider";
import { LoadingProvider } from "../context/LoadingContext";
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { PostsProvider } from '../context/PostsContext';
import { ProductsProvider } from '../context/ProductsContext';
import { CitasProvider } from '../context/CitasContext';

function LayoutContent() {
  const { token, loading, user } = useContext(AuthContext);
  const router = useRouter();
  useEffect(() => {
    if (!loading) {
      if (token) {
        router.replace('/(tabs)');  // 🔹 Ir al home si hay token
      } else {
        router.replace('/(auth)'); // 🔹 Ir al login si no hay token
      }
    }
  }, [token, loading]);
  const [fontsLoaded] = useFonts({
    'poppins-regular': Poppins_400Regular,
    'poppins-semibold': Poppins_600SemiBold,
    'poppins-bold': Poppins_700Bold,
  });
  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <View className='flex-1'>
      {
        token?(
            <Stack
              screenOptions={{
                headerShown:false,
              }}
            />
        ):(
            <Stack
              screenOptions={{headerShown:false}}
            >
              <Stack.Screen name='(auth)/index'
                options={{
                  animation: 'slide_from_left',
                  animationTypeForReplace:'push'
                }}
              />
              <Stack.Screen name='(auth)/login'
                options={{
                  animation: 'simple_push' 
                }}
              />
              <Stack.Screen name='(auth)/register'
                options={{
                  animation:'slide_from_right',
                }}
              />
            </Stack>
        )
      }

    </View>
  ) // Esto representa la pantalla activa según la ruta
}

export default function App() {
  return (
    <GestureHandlerRootView>
      <AuthProvider>
        <CitasProvider>
          <PostsProvider>
            <ProductsProvider>
              <LoadingProvider>
              <StatusBar/>
                <ActionSheetProvider>
                    <LayoutContent />
                    <Toast config={toastConfig}/>
                </ActionSheetProvider>
              </LoadingProvider>
            </ProductsProvider>
          </PostsProvider>
        </CitasProvider>
      </AuthProvider>
    </GestureHandlerRootView>
  );
}
