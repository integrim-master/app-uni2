import { Link, Slot, Stack, usePathname, useRouter } from 'expo-router';
import { useContext, useEffect, useState } from 'react';
import { AuthContext, AuthProvider } from '../context/AuthContext';
import "../global.css"
import { ActivityIndicator, Pressable, SafeAreaView, View } from 'react-native';
import { NotificationIcon } from '../components/Icons';
import { ImageProfile } from '../components/ImageProfile';
import { Logo } from '../components/Logo';
import Avatar from "../assets/images/avatar.jpg"

function LayoutContent() {
  const { token, loading, user, membershipData } = useContext(AuthContext);
  const pathname = usePathname();
  const router = useRouter();

  const [isMounted, setIsMounted] = useState(false);


  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (isMounted && !loading) {
      const authPages = ['/login', '/registro'];
      const isAuthPage = authPages.includes(pathname);

      if (!token && !isAuthPage) {
        router.replace('/login');
      } else if (token && isAuthPage) {
        router.replace('/(tabs)');
      }
    }
  }, [isMounted, token, loading, pathname]);

  if (loading) {
    return (
      <View className="flex-1 justify-center items-center bg-white">
        <ActivityIndicator size="large" color="#000" />
      </View>
    );
  }
  return (
        <View className="flex-1 bg-slate-100">
        {
          token ? (
            <Stack
              screenOptions={{
                headerTitle: '', 
                headerTintColor: "black",
                headerStyle: { backgroundColor: "white" },
                headerLeft: () => <Logo />,
                headerRight: () => (
                  <SafeAreaView className="flex-row items-center">
                    <Link asChild href="/(tabs)">
                      <Pressable>
                        {({ pressed }) => (
                          <NotificationIcon className={pressed ? "opacity-50" : "opacity-100"} style={{ width: 30, height: 30 }} />
                        )}
                      </Pressable>
                    </Link>
                    <Link asChild href="/(tabs)/perfil">
                      <Pressable>
                        {({ pressed }) => (
                          <View className="flex-row items-center">
                            <ImageProfile
                              source={Avatar}
                              className={`w-14 h-14 rounded-full border-2 ${pressed ? "opacity-50" : "opacity-100"}`}
                            />
                            <View className="w-5" />
                          </View>
                        )}
                      </Pressable>
                    </Link>
                  </SafeAreaView>
                ),
              }}
            />
          ) : (
            <Stack
              screenOptions={{headerShown:false}}
            />
          )
        }

      </View>
  )
}

export default function App() {
  return (
    <AuthProvider>
          <LayoutContent />
    </AuthProvider>
  );
}
