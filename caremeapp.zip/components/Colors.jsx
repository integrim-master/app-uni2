import { View, Text } from 'react-native'
import React from 'react'

export const Colors = {
    Card: '#3A3A3A',
    Circle: '#242424',
    champage: '#F7E7CE',
    fondo: '#2C2C2C',
    dark: '#D4AF37'
}