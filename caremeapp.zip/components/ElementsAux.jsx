import { View, Text, Image } from 'react-native'
import React from 'react'
import ImageAvatar from "../assets/images/avatar.jpg"

export const Espace = (props) => {
  return (
    <View {...props}>
    </View>
  )
} 

export const Line = (props) => {
  return (
    <View {...props}>

    </View>
  )
}