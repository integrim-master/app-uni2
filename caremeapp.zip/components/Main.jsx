import React from 'react'
import { Text, View } from 'react-native'
import { Screen } from './Screen'
import { NotificationIcon } from './Icons'

export function Main() {
  return (
    <Screen>
        <Text>HOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDOHOLA MUNDO</Text>
    </Screen>
  )
}
