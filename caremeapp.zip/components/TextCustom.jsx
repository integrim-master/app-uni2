import { Text } from "react-native";
import { useFonts, Poppins_400Regular, Poppins_700Bold } from "@expo-google-fonts/poppins";

export const TextIntro = ({ style, children, className, ...props }) => (
    <Text className={`text-4xl ${className}`} {...props} style={[{fontFamily: "poppins-regular"}, style]}>
        {children}
    </Text>
)

export const TextTitles = ({ style, children, className, ...props }) => (

    <Text className={`text-2xl ${className}`} {...props} style={[{fontFamily: "poppins-regular"}, style]}>
        {children}
    </Text>
)

export const TextSubTitles = ({ style, children, className, ...props }) => (
    <Text  className={`text-xl ${className}`} {...props} style={[{fontFamily: "poppins-regular"}, style]}>
        {children}
    </Text>
)

export const TextContent = ({ style, children, className, ...props }) => (
    <Text  className={`text-base ${className}`} {...props} style={[{fontFamily: "poppins-regular"}, style]}>
        {children}
    </Text>
)

export const TextSmall = ({ style, children, className, ...props }) => (
    <Text className={`text-sm ${className}`} {...props} style={[{fontFamily: "poppins-regular"}, style]}>
        {children}
    </Text>
)

export const TextTiny = ({ style, children, className, ...props }) => (
    <Text className={`text-xs ${className}`} {...props} style={[{fontFamily: "poppins-regular"}, style]}>
        {children}
    </Text>
)

export const TextMix = ({ style, children, className, ...props }) => (
    <Text className={`${className}`} {...props} style={[{fontFamily: "poppins-regular"}, style]}>
        {children}
    </Text>
)
