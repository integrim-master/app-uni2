import { View, Text, Pressable } from 'react-native'
import React from 'react'
import { ItemsHistory } from '../History/ItemsHistory'
import { Line } from '../../ElementsAux'
import { Colors } from '../../Colors'
import { Link } from 'expo-router'

export function HistorialCitas({dark, light, transparent}) {
  return (
    <View className="gap-3">
      <View className="justify-between flex-row items-center">
        <Text className="text-3xl text-black font-medium">Próximas Citas</Text>
        <Link asChild href={`/(tabs)/citas`}>        
          <Pressable>
            {({ pressed }) => (
              <Text className={`text-xl font-normal ${pressed ? "opacity-50" : "opacity-100"} text-gray-500`}>Ver todas</Text>
            )}
          </Pressable>
        </Link>
      </View>
      <View>
        <View className="gap-1">
          <ItemsHistory dark={dark} light={light} transparent={transparent} />
          <Line className="border-b-2 border-b-gray-100 h-1 w-full"/>
          <ItemsHistory dark={dark} light={light} transparent={transparent} />
        </View>
      </View>
    </View>
  )
}