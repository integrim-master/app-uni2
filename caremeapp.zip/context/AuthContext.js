// context/AuthContext.js
import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import wpService from '../services/wordpress';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [token, setToken] = useState(null);
    const [user, setUser] = useState(null);
    const [membershipData, setMembershipData] = useState(null);
    const [loading, setLoading] = useState(true);

    const fetchData = async (currentToken) => {
        const userData = await wpService.getCurrentUser();
        setUser(userData);

        if (userData && userData.membresia) {
            const membership = await wpService.getMembershipData(userData.membresia);
            setMembershipData(membership);
        } else {
            setMembershipData(null);
        }
    };

    const refreshUserData = async () =>  {
        if (!token) return;
        try {
        await fetchData(token);
        } catch (error) {
        console.error("Error refrescando usuario:", error);
        }
    };

    useEffect(()=> {
        const init = async () => {
            try{
                await wpService.initialize();
                if(wpService.token) {
                    setToken(wpService.token);
                    const userData = await wpService.getCurrentUser();
                    setUser(userData)
                    if (userData && userData.membresia) {
                        const membership = await wpService.getMembershipData(userData.membresia);
                        setMembershipData(membership);
                    }
                }
                setLoading(false)
            } catch (error) {
                console.error('Error en AuthProvider:', error);
                setToken(null);
                setUser(null);
                setMembershipData(null);
            } finally {
                setLoading(false);
            }
        }
        init();
    }, []);

    const applicationBenefit = async (procedimientoLabel, procedimiento) => {
        const name = user.display_name
        const response = await wpService.applicationBenefit(user?.id, name, user?.ciudad, user?.telefono, user?.identificacion, procedimientoLabel, procedimiento );
        return response
    }

    const updateUser = async (data) => {
        const userID = user.id;
        const response = await wpService.updateUserData(userID, data);
        return response;
    }

    const login = async(username, password) => {
        const data = await wpService.login(username, password);

        // 🔑 actualizar el AuthContext
        setToken(data.token);

        // 🔑 actualizar el wpService en memoria
        wpService.token = data.token;

        // 🚀 ahora sí ya puedes pedir el user
        const userData = await wpService.getCurrentUser();
        setUser(userData);

        if (userData && userData.membresia) {
            const membership = await wpService.getMembershipData(userData.membresia);
            setMembershipData(membership);
        }
    }

    const logout = async () => {
        await wpService.logout();
        setToken(null);
        setUser(null)
    }
    return(
        <AuthContext.Provider 
            value={{
                token,
                login,
                logout,
                loading,
                user,
                membershipData,
                refreshUserData,
                applicationBenefit,
                updateUser
            }}
        >
            {children}
        </AuthContext.Provider>
    )




}