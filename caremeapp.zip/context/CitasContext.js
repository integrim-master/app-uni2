import { View, Text } from 'react-native'
import React, { createContext, useContext, useEffect, useState } from 'react'
import wpService from '../services/wordpress';
import { AuthContext } from './AuthContext';


export const CitasContext = createContext()
export const CitasProvider= ({children}) => {
    const [citas, setCitas] = useState([]);
    const {token} = useContext(AuthContext)
    const fetchCitas = async () => {
        try{
            const response = await wpService.getCitasUser()
            return response
        }catch {
            console.log("No se pudo cargar");
        }
    };

    useEffect(()=>{
        const init = async () => {
            try{
                const data = await fetchCitas();
                setCitas(data)
            } catch (error) {
                console.error('Error en no se pudo traer las citas:', error);
            }
        }
        init();
    }, [token])

    return(
        <CitasContext.Provider
            value={{
                citas,
            }}
        >
            {children}
        </CitasContext.Provider>
    )
}