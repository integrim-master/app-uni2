import { View, Text } from 'react-native'
import React, { createContext, useEffect, useState } from 'react'
import wpService from '../services/wordpress';
import { analyzeImage } from '../services/n8n';

export const PostsContext = createContext()
export const PostsProvider = ({children}) => {
    const [token, setToken] = useState(null);
    const [loading, setLoading] = useState(false);
    const [statusMsg, setStatusMsg] = useState("");
    const [lastReport, setLastReport] = useState(null);

    const fetchLastReport = async () => {
        try {
            const data = await wpService.getLastReport();
            setLastReport(data);
            return data
        } catch (err) {
            throw err;
        } finally {
            setLoading(false);
        }
    };

    const uploadReport = async (photo) => {
        try {
            const { diagnostico, procedimientos } = await analyzeImage(photo);
            const imageId = await wpService.uploadImage(photo);
            const report = await wpService.createReport(
                diagnostico,
                procedimientos,
                imageId
            );
            await fetchLastReport();
            return report;
        } catch {
            console.log("Error ❌", err.message || "No se pudo guardar el reporte");
        }
    };

    useEffect(()=>{
        const init = async () => {
            try{
                await wpService.initialize();
                if(wpService.token) {
                    setToken(wpService.token);
                    const data = await fetchLastReport();
                    setLastReport(data)
                }
            } catch (error) {
                console.error('Error en AuthProvider:', error);
                setToken(null);
                setLastReport(null);
            }
        }
        init();
    }, [])

    return(
        <PostsContext.Provider
            value={{
                lastReport,
                fetchLastReport,
                uploadReport
            }}
        >
            {children}
        </PostsContext.Provider>
    )
}